import pandas as pd
import numpy as np
import torch
from torch.utils.data import Dataset, DataLoader
import os
from glob import glob

class MyDataset(Dataset):
    def __init__(self, datadir):
        self.datadir = datadir
        self.originals = []

        for csv_file in glob(os.path.join(self.datadir, '*.csv')):
            x = load_data(csv_file)
            x = (x-x.min()) / (x.max()-x.min())
            self.originals.append(x)

        self.nums = 1000
        self.y_cnt = 3

        self.inputs = []
        self.labels = []


        for i in range(self.nums):
            indexes = np.arange(self.y_cnt)
            np.random.shuffle(indexes)

            label = np.zeros(3)
            input = np.zeros(self.originals[0].shape)
            for j in range(self.y_cnt):
                percent = np.random.rand()
                label[indexes[j]] = percent
                input += percent*self.originals[indexes[j]]

            self.inputs.append(input)
            self.labels.append(label)

    def __len__(self):
        return self.nums

    def __getitem__(self, index):
        NF = 0.5 # 噪声系数，可以根据实验需求来调整
        x = self.inputs[index] + (np.random.rand() - 0.5) * 0.05 * NF
        y = self.labels[index]

        x = np.expand_dims(x, 0)
        return torch.tensor(x).float(), torch.tensor(y).float()


def load_data(csv_file):
    # 读取CSV文件
    data_frame = pd.read_csv(csv_file)

    # 将数据转换为NumPy数组
    numpy_array = data_frame.to_numpy()[0]

    return numpy_array




if __name__=='__main__':
    dataset = MyDataset('./data/use')
    dataloader = DataLoader(dataset, num_workers=0, batch_size=4, shuffle=False)


    for x, y in dataloader:
        print(x.shape, y)
