import torch
import torch.nn as nn
from dataset import MyDataset
from torch.utils.data import Dataset, DataLoader, random_split
import torch.optim as optim
from sklearn.metrics import mean_squared_error, mean_absolute_error
import numpy as np
np.random.seed(10)



class CNN(nn.Module):
    def __init__(self, num_classes):
        super(CNN, self).__init__()
        self.conv1 = nn.Conv1d(1, 16, kernel_size=7, stride=7)
        self.conv2 = nn.Conv1d(16, 32, kernel_size=7, stride=7)
        self.conv3 = nn.Conv1d(32, 32, kernel_size=7, stride=3)

        self.pool = nn.AdaptiveAvgPool1d(1)

        self.atten = nn.Sequential(
            nn.Linear(71, 16),
            nn.ReLU(),
            nn.AdaptiveAvgPool1d(1),
            nn.Sigmoid()
        )

        self.fc = nn.Linear(32, num_classes)


    def forward(self, x):
        x = self.conv1(x)
        x = torch.relu(x)
        x = self.conv2(x)
        x = torch.relu(x)

        atten = self.atten(x)
        x = x * atten

        x = self.conv3(x)
        x = torch.relu(x)

        x = self.pool(x)
        x = x.view(x.size(0), -1)
        x = self.fc(x)
        x = nn.Sigmoid()(x)

        return x



# 回归类别数量
num_classes = 3

# 创建模型实例
model = CNN(num_classes)
model.train()

dataset = MyDataset('./data/use')
# 划分训练集和验证集
train_size = int(0.8 * len(dataset))
val_size = len(dataset) - train_size

train_dataset, val_dataset = random_split(dataset, [train_size, val_size])

# 创建数据加载器
train_loader = DataLoader(train_dataset, batch_size=128, shuffle=True)
val_loader = DataLoader(val_dataset, batch_size=128, shuffle=False)

criterion = nn.MSELoss()
optimizer = optim.Adam(model.parameters(), lr=0.1)
epochs = 200

# 模型训练
for epoch in range(epochs):
    losses = []
    model.train()
    for i, (inputs, labels) in enumerate(train_loader):

        optimizer.zero_grad()

        outputs = model(inputs)

        loss = criterion(outputs, labels)
        loss.backward()
        optimizer.step()
        losses.append(loss.clone().detach())


    # 模型评估
    all_predictions = np.zeros((0,3))
    all_labels = np.zeros((0,3))

    model.eval()

    with torch.no_grad():
        for data in val_loader:
            inputs, labels = data

            outputs = model(inputs)

            all_predictions = np.concatenate([all_predictions, outputs.numpy()], axis=0)
            all_labels = np.concatenate([all_labels, labels.numpy()], axis=0)

    s1 = f'1B: {labels[0][0].item()}, EA: {labels[0][1].item()}, MB: {labels[0][2].item()}'
    s2 = f'1B: {outputs[0][0].item()}, EA: {outputs[0][1].item()}, MB: {outputs[0][2].item()}'

    print(f'真实浓度: {s1}')
    print(f'预测浓度: {s2}')

    mse = 0
    mae = 0
    for i in range(3):
        mse += mean_squared_error(all_labels[:, i], all_predictions[:, i])/3.0
        mae += mean_absolute_error(all_labels[:, i], all_predictions[:, i])/3.0

    print(f'epoch: {epoch}, mse: {mse}, mae: {mae}, loss: {np.mean(losses)}')
